# kodachi

Linux Kodachi operating system is based on Debian 8.6 it will provide you with a secure, anti forensic, and anonymous operating system considering all features that a person who is concerned about privacy would need to have in order to be secure.

Kodachi is very easy to use all you have to do is boot it up on your PC via USB drive then you should have a fully running operating system with established VPN connection + Tor Connection established + DNScrypt service running. No setup or Linux knowledge is required from your side we do it all for you. The entire OS is functional from your temporary memory RAM so once you shut it down no trace is left behind all your activities are wiped out.

Kodachi is a live operating system, that you can start on almost any computer from a DVD, USB stick, or SD card. It aims at preserving your privacy and anonymity, and helps you to:

    Use the Internet anonymously.
    All connections to the Internet are forced to go through the VPN then Tor network with DNS encryption.
    Leave no trace on the computer you are using unless you ask it explicitly.
    Use state-of-the-art cryptographic and privacy tools to encrypt your files, emails and instant messaging.

Kodachi is based on the solid Linux Debian with customized XFCE this makes Kodachi stable, secure, and unique 

To knnow more or to download it from the offcial website please visit:
https://www.digi77.com/linux-kodachi/
